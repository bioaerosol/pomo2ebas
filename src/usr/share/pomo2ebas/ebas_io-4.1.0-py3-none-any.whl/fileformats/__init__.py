"""
Module fileformats: support basic file formats
$Id: __init__.py 2631 2021-03-26 17:44:02Z pe $
 ascii_fixedwidth: fixed column ascii format
 NasaAmes1001:     NasaAmes1001 file I/O
 ...
"""
__version__ = 'V.1.10.00-next-devel'
