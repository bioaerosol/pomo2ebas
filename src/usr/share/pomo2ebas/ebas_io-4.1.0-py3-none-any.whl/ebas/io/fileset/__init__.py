"""
$Id: __init__.py 2466 2020-07-10 13:20:48Z pe $

EBAS I/O fileset module
"""

from .fileset import EbasIOResultSet, NoDataDOI