"""
ebas.domain.basic_domain_logic
$Id: __init__.py 2427 2020-03-19 23:09:09Z pe $

EBAS basic domain logic used by ebas.domain and ebas.io
"""
