"""
$Id: ca.py 2466 2020-07-10 13:20:48Z pe $

EBAS Masterdata Class for calibration scales

This module implements the class EbasMasterCA.
"""

from .offline_masterdata import CAOfflineMasterData
from .base import EbasMasterBase

class EbasMasterCA(EbasMasterBase, CAOfflineMasterData):
    """
    Domain Class for calibration scale masterdata.
    Objects of this class do not represent entities, this class provides class
    methods for handling sensor types and checking them against master data.
    Sensor type master data are retrieved from database or from offline storage
    when no database access is possible.
    """

    # read offline masterdata for SE (sensor types)
    # Those are fallback values, will be read from database as soon as possible.
    CAOfflineMasterData.read_pickle_file()

    def __init__(self, dbh=None):
        """
        Read se masterdata if dbh is provided.
        """
        CAOfflineMasterData.__init__(self)
        if not self.__class__.INIT and dbh:
            self.from_db(dbh)

    @classmethod
    def exist_calibrationscale(cls, cal_scale):
        """
        Check if the sensor type exists (regardless of FT and CO).
        Parameters:
            sensor_type    sensor type code to be checked
        Returns:
            True/False
        """
        if any([key[1] == cal_scale for key in list(cls.META.keys())]):
            return True
        return False
