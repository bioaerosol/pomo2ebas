"""
atmos_phys unit conversion routines for gasses.
"""

import re
from nilutility.datatypes import DataObject
from .base import ConvertBaseFactor
from .elements import ELEMENTS

R = 8.3144621  # Gas constant

MASSCONC = 0b0
MIXING = 0b1

MASSCONC_TO_MASSCONC = (MASSCONC << 1) + MASSCONC
MASSCONC_TO_MIXING = (MASSCONC << 1) + MIXING
MIXING_TO_MASSCONC = (MIXING << 1) + MASSCONC
MIXING_TO_MIXING = (MIXING << 1) + MIXING

class ConvertGasBase(ConvertBaseFactor):  # pylint: disable=W0223
    # W0223: Method ... is abstract in base class but is not overridden
    """
    Base class for gas conversions (mixing ratio / mass concentration).

    The gas conversion classes have their own base class. A lot of the logic
    is generically handled here. The final classes (conversion for single
    coponens) are only implementing by setting those class attributes.

    Attributes:
        MASS_CONC_ELEMENT: For parameters where only the mass of one element of
                           a component is used as mass concentartion unit.
                           E.g. sulfor_dioxide, ug S/m3
                           (-> MASS_CONC_ELEMENT = 'S')
        MOLAR_MASS: molar mass of the component or, in case of
                    MASS_CONC_ELEMENT, the molar mass of that element
        COMP_NAME: The EBAS component name, can be used to doublecheck molar 
                   mass (using the parameter synonyms, parsing the chemical
                   formular)
    TODO: check COMP_NAME
    TODO: in case of MASS_CONC_ELEMENT, an additional type of conversion can be
          defined: from/to mass concentration using the whole molecule
          E.g. in case of sulfor_dioxide, ug S/m3, additional conversion to
          ug/m3
    """

    MASS_CONC_ELEMENT = None
    MOLAR_MASS = None
    COMP_NAME = None

    def __init__(self, from_unit, to_unit, roundoffset=0, maxround=None,
                 temperature=273.15, pressure=101325):
        # pylint: disable=R0913
        # R0913: Too many arguments
        """
        Set up conversion object.
        Parameters:
            from_unit:
            to_unit: conversion from and to unit. Must be checked in
                     _set_parameters of the final class.
            roundoffset: rounding offset (usually +1 for import and -1 for
                         export)
            maxround: maximum rounding threshold, do no round coarser then
                      this should be used for export conversion only
                      (rounding expressed like in round function, 0=integer,
                      1=1digit after comma)
            temperature: temperature (standard conditions)
            pressure: pressure (standard conditions)
        For gas conversions, temperature and pressure (standard conditions for
        mass concentrations) are additionally needed.
        """
        # additional attributes for standard conditions.
        self.temperature = temperature
        self.pressure = pressure
        # call base class init
        super(ConvertGasBase, self).__init__(
            from_unit, to_unit, roundoffset=roundoffset, maxround=maxround)

    @classmethod
    def _parse_unit(cls, unit):
        """
        Parses a unit string
        Returns:
            tuple (prefix_factor, conversion_type)
            prefix_factor   factor which accounts for yhe metrix prefix
                            m=1E-3, u=1E-6, n=1E-9, p=1E-12
            conversion type MASSCONC_TO_MASSCONC, MASSCONC_TO_MIXING,
                            MIXING_TO_MASSCONC, MIXING_TO_MIXING
        Raises Value error
        """
        prefixes = {
            None: 1,
            'm': 1.0E-3,
            'u': 1.0E-6,
            'n': 1.0E-9,
            'p': 1.0E-12,
        }
        parts_per = {
            'ppm': 1.0E-6,
            'ppmv': 1.0E-6,
            'ppb': 1.0E-9,
            'ppbv': 1.0E-9,
            'ppt': 1.0E-12,
            'pptv': 1.0E-12,
        }
        reg = re.match(
            '^([munp])?g{}/m3$'.format(
                (' ' + cls.MASS_CONC_ELEMENT) if cls.MASS_CONC_ELEMENT else ''),
            unit)
        if reg:
            return prefixes[reg.group(1)], MASSCONC
        reg = re.match('^([munp])?mol/mol$', unit)
        if reg:
            return prefixes[reg.group(1)], MIXING
        if unit in parts_per:
            return parts_per[unit], MIXING
        raise ValueError("Unit '{}' cannot be parsed".format(unit))

    def _set_parameters(self):
        """
        Sets the conversion parameters.
        Called from base class init.
        Parameters:
            None
        Returns:
            None
        Raises ValueError when unit cannot be parsed
        """
        try:
            from_prefix, from_type = self._parse_unit(self.from_unit)
            to_prefix, to_type = self._parse_unit(self.to_unit)
        except ValueError:
            raise ValueError("Convesion from {} to {} is not supported".format(
                self.from_unit, self.to_unit))
        self.parameters = DataObject(factor=None)
        self.parameters.conv_type = (from_type << 1) + to_type
        if self.parameters.conv_type == MIXING_TO_MASSCONC:
            self.parameters.factor = (
                (self.__class__.MOLAR_MASS /
                 (R*self.temperature/self.pressure)) *
                (from_prefix / to_prefix))
        elif self.parameters.conv_type == MASSCONC_TO_MIXING:
            self.parameters.factor = (
                ((R*self.temperature/self.pressure) /
                 self.__class__.MOLAR_MASS) *
                (from_prefix / to_prefix))
        else:
            self.parameters.factor = from_prefix / to_prefix

    def conversion_string(self, from_val=None, to_val=None):
        """
        Generates a conversion parameter string for the conversion.
        E.g. "from nmol/mol to ug/m3 273.15 K, 1013.25 hPa, using factor 1.234",
             "from nmol/mol to ug/m3 at 273.15 K, 1013.25 hPa, no conversion "
                 "factor used (no nonzero, valid values)"
        Parameters:
            from_val:
            to_val:
               If from_val and to_val are given, the values are included in the
               string (used to document conversion of uncertainty or detection
               limit values).
        Returns a string for documenting the conversion.
        """
        from_val = "{} ".format(from_val) if from_val is not None else ""
        to_val = "{} ".format(to_val) if to_val is not None else ""
        if self.rounding is None:
            convf = "no conversion factor (no nonzero, valid values)"
        else:
            convf = "conversion factor {:.{rdigits}f}".format(
                self.parameters.factor, rdigits=max(self.rounding+2, 0))

        if self.parameters.conv_type == MIXING_TO_MASSCONC:
            return ("from '{}{}' to '{}{}' at {} K, {} hPa, {}").format(
                from_val, self.from_unit, to_val, self.to_unit,
                self.temperature, self.pressure/100.0, convf)
        elif self.parameters.conv_type == MASSCONC_TO_MIXING:
            return ("from '{}{}' at {} K, {} hPa to '{}{}', {}").format(
                from_val, self.from_unit, self.temperature, self.pressure/100.0,
                to_val, self.to_unit, convf)
        return ("from '{}{}' to '{}{}', {}").format(
            from_val, self.from_unit, to_val, self.to_unit, convf)


class ConvertNOx(ConvertGasBase):
    """
    Conversion class for NOx (NO, NO2, NOx) conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """
    MASS_CONC_ELEMENT = 'N'
    MOLAR_MASS = ELEMENTS['N']['MolarMass']


class ConvertAmmonia(ConvertGasBase):
    """
    Conversion class for NH3
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """
    MASS_CONC_ELEMENT = 'N'
    MOLAR_MASS = ELEMENTS['N']['MolarMass']


class ConvertHydrochloricAcid(ConvertGasBase):
    """
    Conversion class for HCl
    Mixing ratio (nmol/mol) / mmass concentration (ug Cl/m3).
    """
    MASS_CONC_ELEMENT = 'Cl'
    MOLAR_MASS = ELEMENTS['Cl']['MolarMass']


class ConvertNitricAcid(ConvertGasBase):
    """
    Conversion class for HNO3
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """
    MASS_CONC_ELEMENT = 'N'
    MOLAR_MASS = ELEMENTS['N']['MolarMass']


class ConvertNitrousAcid(ConvertGasBase):
    """
    Conversion class for HNO3
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """
    MASS_CONC_ELEMENT = 'N'
    MOLAR_MASS = ELEMENTS['N']['MolarMass']


class ConvertSulphurDioxide(ConvertGasBase):
    """
    Conversion class for NOx (NO, NO2, NOx) conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug N/m3).
    """
    MASS_CONC_ELEMENT = 'S'
    MOLAR_MASS = ELEMENTS['S']['MolarMass']


class ConvertOzone(ConvertGasBase):
    """
    Conversion class for ozone conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = 3 * ELEMENTS['O']['MolarMass']
    COMP_NAME = 'ozone'


class ConvertEthanal(ConvertGasBase):
    """
    Conversion class for ethanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (2 * ELEMENTS['C']['MolarMass'] +
                  4 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'ethanal'


class ConvertEthanol(ConvertGasBase):
    """
    Conversion class for ethanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (2 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'ethanol'


class ConvertMethanal(ConvertGasBase):
    """
    Conversion class for methanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (1 * ELEMENTS['C']['MolarMass'] +
                  2 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'methanal'


class ConvertPropanone(ConvertGasBase):
    """
    Conversion class for propanone conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (3 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'propanone'


class ConvertPropanal(ConvertGasBase):
    """
    Conversion class for propanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (3 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'propanal'


class ConvertNPropanol(ConvertGasBase):
    """
    Conversion class for n-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (3 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'n-propanol'


class ConvertEthanedial(ConvertGasBase):
    """
    Conversion class for glyoxal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (2 * ELEMENTS['C']['MolarMass'] +
                  2 * ELEMENTS['H']['MolarMass'] +
                  2 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'ethanedial'


class Convert2Oxopropanal(ConvertGasBase):
    """
    Conversion class for methylglyoxal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (3 * ELEMENTS['C']['MolarMass'] +
                  4 * ELEMENTS['H']['MolarMass'] +
                  2 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = '2-oxopropanal'


class Convert2Propenal(ConvertGasBase):
    """
    Conversion class for 2-propenal conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (3 * ELEMENTS['C']['MolarMass'] +
                  4 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = '2-propenal'


class Convert3Buten2One(ConvertGasBase):
    """
    Conversion class for 3-buten-2-one conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (4 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = '3-buten-2-one'


class ConvertButanone(ConvertGasBase):
    """
    Conversion class for butanone conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (4 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'] +
                  1 * ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'butanone'


class ConvertStyrene(ConvertGasBase):
    """
    Conversion class for styrene conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (8 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'styrene'

class ConvertHexanal(ConvertGasBase):
    """
    Conversion class for haxanal conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (6 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'hexanal'


class ConvertNButanal(ConvertGasBase):
    """
    Conversion class for n-butanal conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (4 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'n-butanal'


class ConvertNaphthalene(ConvertGasBase):
    """
    Conversion class for naphthalene conversions:
    Mixing ratio (pmol/mol) / mmass concentration (ng/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'naphthalene'


class ConvertPentanal(ConvertGasBase):
    """
    Conversion class for pentanal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (5 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'pentanal'


class Convert2Methylpropenal(ConvertGasBase):
    """
    Conversion class for 2-methylpropenal conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (4 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = '2-methylpropenal'


class ConvertBenzaldehyde(ConvertGasBase):
    """
    Conversion class for benzaldehyde conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (7 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'benzaldehyde'


class Convert2Propanol(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (3 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = '2-propanol'

class Convert123Trimethylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = '1-2-3-trimethylbenzene'


class Convert124Trimethylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = '1-2-4-trimethylbenzene'


class Convert135Trimethylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = '1-3-5-trimethylbenzene'


class Convert1Ethyl3Methylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = '1-ethyl-3-methylbenzene'


class Convert1Ethyl4Methylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = '1-ethyl-4-methylbenzene'


class Convert3Carene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = '3-carene'


class ConvertAcenaphthene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (12 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'acenaphthene'


class ConvertAcenaphthylene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (12 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'acenaphthylene'


class ConvertAnthracene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (14 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'anthracene'


class ConvertFluorene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (13 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'fluorene'


class ConvertAlphaPinene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'alpha-pinene'


class ConvertBenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (6 * ELEMENTS['C']['MolarMass'] +
                  6 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'benzene'


class ConvertBetaPinene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'beta-pinene'


class ConvertCamphene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'camphene'


class ConvertEthylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (8 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'ethylbenzene'


class ConvertLimonene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'limonene'


class ConvertLinalool(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  18 * ELEMENTS['H']['MolarMass'] +
                  ELEMENTS['O']['MolarMass'])
    COMP_NAME = 'linalool'


class ConvertMPXylene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (8 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'm-p-xylene'


class ConvertMyrcene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'myrcene'


class ConvertNDecane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  22 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-decane'


class ConvertNDodecane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (12 * ELEMENTS['C']['MolarMass'] +
                  26 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-dodecane'


class ConvertNNonane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  20 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-nonane'


class ConvertNOctane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (8 * ELEMENTS['C']['MolarMass'] +
                  18 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-octane'


class ConvertNPentadecane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (15 * ELEMENTS['C']['MolarMass'] +
                  32 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-pentadecane'


class ConvertNPropylbenzene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (9 * ELEMENTS['C']['MolarMass'] +
                  12 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-propylbenzene'


class ConvertNTetradecane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (14 * ELEMENTS['C']['MolarMass'] +
                  30 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-tetradecane'


class ConvertNTridecane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (13 * ELEMENTS['C']['MolarMass'] +
                  28 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-tridecane'


class ConvertNUndecane(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (11 * ELEMENTS['C']['MolarMass'] +
                  24 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'n-undecane'


class ConvertOXylene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (8 * ELEMENTS['C']['MolarMass'] +
                  10 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'o-xylene'


class ConvertPCymene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  14 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'p-cymene'


class ConvertSabinene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'sabinene'


class ConvertTerpinolene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (10 * ELEMENTS['C']['MolarMass'] +
                  16 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'terpinolene'


class ConvertToluene(ConvertGasBase):
    """
    Conversion class for 2-propanol conversions:
    Mixing ratio (nmol/mol) / mmass concentration (ug/m3).
    """
    MASS_CONC_ELEMENT = None
    MOLAR_MASS = (7 * ELEMENTS['C']['MolarMass'] +
                  8 * ELEMENTS['H']['MolarMass'])
    COMP_NAME = 'toluene'


def convf_volume_standard(temp1=273.15, pres1=101325, temp2=273.15,
                          pres2=101325):
    """
    Conversion factor for converting concentrations from one condition to
    another.
    Parameters:
        temp1: temperature to convert from
        pres1: pressure to convert from
        temp2: temperature to convert to
        pres2: pressure to convert to
    Returns:
        conversion factor
    Attention:
        all temperatures in K, all pressures in Pa (not hPa!!!)
    """
    return (temp1 * pres2) / (temp2 * pres1)
